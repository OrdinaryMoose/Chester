---
status: Open
date: 2026-05-10
deciders: [M]
related_docs: [05-domain-spec]
---

# ADR-0010: First-class lane membership pointer on NCs

## Status

**Open / deferred.** This decision is not yet made. The ADR exists to record the trade-off, retain it for future revisit, and prevent the question from being lost. Revisit when usage patterns demonstrate need (or absence of need).

## Context

The proof system organizes claims around Concerns: each Concern is a problem the design must address; each Resolve Condition (RC) anchors to a specific Concern via `problem_anchor`; each RC's grounding includes the Necessary Conditions (NCs) that support it. NCs therefore participate in a Concern's argument *transitively* — an NC supports an RC that anchors a Concern.

The question this ADR records: should NCs *directly* carry lane membership pointers (a `concerns_addressed[]` field naming the Concerns whose lanes they participate in), making lane membership first-class structural data rather than a transitive derivation?

The case in favor:

- **Render quality.** A "render Concern C's lane" operation becomes a direct query against `lane_member(C, NC)` facts rather than a transitive query through RCs. Per-lane slicing as a render mode (the slice protocol — see Domain Spec §10.2 alternatives) becomes first-class.
- **Closure granularity.** Per-lane closure status (this Concern's lane has fully ratified support; that Concern's lane has one ungrounded NC) becomes a direct query. The closing argument can report per-lane signals plus a cross-lane reconciliation summary, rather than a single global "all concerns covered."
- **Authoring clarity.** When the Agent asserts an NC, declaring which Concerns it serves makes the NC's role explicit. Currently the NC's role is implicit and recovered downstream.
- **Lane membership without RC.** An NC may legitimately serve a Concern *before* an RC has been written for that Concern. The current model has no way to express "this NC is for Concern C" until an RC anchored to C grounds in it. The lane pointer surfaces this earlier.

The case against:

- **Synchronization risk.** With direct membership pointers plus the transitive RC→NC path, two ways exist to determine NC-to-Concern relationship. If they disagree (Agent asserts NC with lane membership `[cern_2]` but later the only RC that grounds in this NC anchors `cern_3`), which is authoritative? An integrity rule can detect the disagreement, but the system has to define the resolution policy.
- **Schema growth.** Every NC carries one more field. The closed-set discipline (Vision §2.2) cautions against expanding the agent's required field surface without demonstrated need.
- **Inference pattern overlap.** The `inference_pattern` field (ADR-0004) already partially captures the NC's role in the argument's structure. Lane membership adds a different dimension; the two together approach over-specification.
- **Derivable today.** The transitive query "which Concerns does this NC participate in?" is already expressible as a Datalog rule in the forward-solve paradigm. The architectural payoff of making it explicit is real but not transformative.

The deeper question is whether the proof's organization around Concerns deserves first-class schema-level representation or whether the transitive derivation is sufficient. The answer depends on how often "lane-shaped" operations turn out to be the right grain: per-lane render, per-lane closure status, per-lane authoring workflow. If these dominate, lane membership is structural; if they remain occasional, the transitive derivation suffices.

## Decision

**Defer.** No commitment is made at this time. The question is preserved here for revisit when:

- The closing-argument render is in production use and per-lane organization is observed to be a frequent need
- The Designer workflow surfaces "review Concern C's lane in isolation" as a recurring request
- Per-lane closure becomes a desired granularity for partial-completion signaling

Until then, the proof system uses transitive derivation: lane membership is computed by Datalog query from the RC anchor + NC grounding relations.

When revisited, this ADR is either:
- **Accepted** with a specific schema addition and an associated migration plan
- **Closed (Rejected)** with rationale, if usage demonstrates transitive derivation is sufficient
- **Superseded** by a different organizing concept (e.g., a `serves(Concern, Claim)` predicate that generalizes beyond NCs)

## Consequences (of deferring)

**Positive:**
- Schema stays minimal; the closed-set discipline holds
- Transitive derivation works adequately for current workflows
- No migration burden for existing proofs

**Negative:**
- Per-lane render mode remains a planned-not-yet-implemented capability
- Per-lane closure granularity unavailable
- Lane membership cannot be asserted until an RC exists

**Neutral:**
- The forward-solve paradigm makes either choice implementable cheaply; this is a small architectural decision in the larger paradigm.
- Reopening the question later costs little — adding a new field to the NC schema with a default backfill is a low-risk migration.

## What would change the decision

The ADR should be revisited if:

1. Three or more workflows surface "per-lane operation" as a primary need
2. The closing-argument render's lane-organization gains widespread use (suggesting lane membership wants first-class representation)
3. Partial-closure signaling (some lanes closed, others open) becomes a desired feature
4. An ADR proposes a more general `serves(Concern, Claim)` predicate generalizing beyond NCs — in which case this ADR is superseded by that one

## References

- Domain Spec §3.4 (NC schema, current grounding structure)
- Domain Spec §3.6 (RC schema, `problem_anchor` to Concern)
- Domain Spec §10 (Render modes; the "lane-slice" planned mode references this ADR)
- ADR-0004 (inference_pattern; the partial structural-role tag already in place)
