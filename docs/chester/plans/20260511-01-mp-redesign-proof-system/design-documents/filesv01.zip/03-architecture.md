---
status: Draft
last_reviewed: 2026-05-10
related_docs: [00-glossary, 01-vision, 02-conops, 04-engine-spec, 05-domain-spec, 06-interface-spec]
related_adrs: [0001, 0002, 0007]
---

# Architecture

This document describes the structural shape of the proof system: its layers, their dependencies, what each layer owns, and the contracts at each boundary. It is the bridge between the philosophy (Vision, ConOps) and the implementation (Specs).

---

## 1. Architectural style

The system uses **hexagonal architecture** (Ports and Adapters) with three layers. The Domain layer sits at the center; the Engine and Interface are adapters bound to the Domain through typed ports.

The architectural style is chosen because:
- **The Domain is the system's identity.** Proof concepts, lifecycle, policies, channeling — these are what make this system this system. They sit at the center.
- **The Engine is replaceable.** Today it is a custom Datalog evaluator. Tomorrow it might be CozoDB or Soufflé. The Domain should not care.
- **The Interface is replaceable.** Today it is MCP. Tomorrow it might be HTTP or a CLI. The Domain should not care.
- **Dependencies flow inward only.** Engine and Interface depend on Domain abstractions; Domain depends on Engine through a port; Domain knows nothing about Interface.

The MVVM analogy works at high level (Engine ≡ Model, Domain ≡ ViewModel, Interface ≡ View) but the precise pattern is hexagonal because there is no UI binding and the Engine is itself an adapter rather than a passive store.

---

## 2. Layer overview

```mermaid
flowchart TD
    subgraph external [External World]
        Agent([LLM Agent])
        Designer([Human Designer])
        FS([File System])
    end

    subgraph interface [Interface Layer]
        MCP[MCP Tool Surface]
        Wire[Wire Format / JSON]
        Persist[Persistence Adapter]
    end

    subgraph domain [Domain Layer]
        Schema[Schema & Translation]
        Mutations[Mutation Operations]
        Policies[Closure / Integrity / Friction Policies]
        Lifecycle[Lifecycle & Authority]
        Render[Render Module]
        Counterfactual[Counterfactual Module]
    end

    subgraph engine [Engine Layer]
        FactStore[Fact Store]
        RuleStore[Rule Store]
        Evaluator[Semi-Naive Evaluator]
        Snapshot[Snapshot / Restore]
    end

    Agent -->|MCP calls| MCP
    Designer -->|MCP calls| MCP
    FS <-->|read/write| Persist

    MCP --> Wire
    Wire --> Mutations
    Persist --> Mutations
    Mutations --> Schema
    Mutations --> Lifecycle
    Schema --> Engine
    Policies --> Engine
    Counterfactual --> Snapshot
    Render --> Engine

    style domain fill:#fff4e1
    style engine fill:#e8f5e8
    style interface fill:#e1f5ff
```

### 2.1 Engine Layer
Pure Datalog evaluator. Generic over predicate symbols and value types. Knows nothing about proofs, designers, or agents. Provides facts, rules, queries, derivation, snapshots.

### 2.2 Domain Layer
The proof system's identity. Owns the design language schema, mutation operations, closure policy, integrity policy, friction policy, lifecycle, authority enforcement, restructuring, rendering, counterfactual reasoning. Uses the Engine for inference; exposes proof-shaped operations to the Interface.

### 2.3 Interface Layer
Adapter between the outside world and the Domain. Owns the MCP tool surface, JSON wire format, file persistence, error classification, render adapters. Knows nothing about closure conditions, friction logic, or Datalog semantics.

---

## 3. The inward dependency rule

Dependencies flow inward only:
- **Interface depends on Domain.** It calls Domain operations; it shapes Domain results for the wire.
- **Domain depends on Engine.** It asserts facts and rules; it issues queries; it consumes bindings and derivation trees.
- **Engine depends on nothing.** It is generic and self-contained.

Forbidden:
- Interface calling Engine directly (must go through Domain)
- Domain reading the wire format or filesystem (Persistence and Wire shape live in Interface)
- Engine knowing about Concerns, Necessary Conditions, or any proof-domain concept

The discipline is structural: each layer exposes a typed surface; outer layers call into inner layers through that surface; inner layers know nothing of outer layers.

---

## 4. Boundary contracts

The contracts between layers are typed surfaces. What flows down: requests. What flows up: results. No cross-layer state-sharing.

### 4.1 Domain ↔ Engine boundary

**Down (Domain → Engine):**
- `assertFact(predicate, args)` — write a base fact
- `retractFact(predicate, args)` — remove a base fact
- `defineRule(headAtom, bodyAtoms, metadata)` — write a Horn clause
- `undefineRule(ruleId)` — remove a rule
- `query(pattern)` — request bindings
- `derive()` — trigger fixed-point computation
- `explain(fact)` — request derivation tree
- `snapshot()` / `restore(token)` — for counterfactuals

**Up (Engine → Domain):**
- Bindings (lists of variable assignments satisfying a query)
- Derivation trees (recursive structures showing why a fact was derived)
- Errors raised as exceptions (Engine never returns Domain-classified errors)

**Forbidden across this boundary:**
- Engine reading Domain state directly
- Domain reaching into Engine internals (indexes, evaluator state)
- Either side serializing to JSON or files (that lives in Interface)

### 4.2 Interface ↔ Domain boundary

**Down (Interface → Domain):**
- Operation calls with typed arguments (deserialized from MCP input)
- Read calls (`getProofState`, `renderProofState`, `renderClosingArgument`, `runCounterfactual`)
- A persistence callback the Domain can invoke to load/save state via the Interface's persistence adapter

**Up (Domain → Interface):**
- Domain results (success + projected state, or domain-classified error)
- Render outputs (markdown, structured objects, Datalog text)

**Forbidden across this boundary:**
- Interface building engine queries directly
- Domain reading JSON or filesystem
- Domain knowing MCP tool names or message formats

### 4.3 External ↔ Interface boundary

**In:**
- MCP tool calls with JSON arguments
- File reads (state files)

**Out:**
- MCP tool responses with JSON content
- File writes (state files, atomic via rename)

This is the only place the system touches the outside world. The Interface owns this entirely.

---

## 5. Canonical mutation flow

The most common operation flow: Agent issues a mutation.

```mermaid
sequenceDiagram
    actor Agent
    participant MCPSurface as MCP Tool Surface
    participant Persist as Persistence Adapter
    participant Mutation as Domain: Mutation
    participant Authority as Domain: Authority
    participant Schema as Domain: Schema
    participant Engine as Engine

    Agent->>MCPSurface: tool call (args, consent)
    MCPSurface->>MCPSurface: validate input shape
    MCPSurface->>Persist: load state
    Persist->>Engine: rebuild engine from state
    Persist-->>MCPSurface: state loaded
    MCPSurface->>Mutation: invoke operation
    Mutation->>Authority: validate consent
    Authority-->>Mutation: ok / refused
    Mutation->>Schema: validate element shape
    Schema-->>Mutation: ok / refused
    Mutation->>Engine: assert facts / define rules
    Engine->>Engine: forward-chain to fixed point
    Mutation->>Engine: query post-conditions
    Engine-->>Mutation: bindings
    Mutation->>Mutation: append to operation log
    Mutation-->>MCPSurface: domain result
    MCPSurface->>Persist: save state
    Persist->>Engine: serialize engine state
    Engine-->>Persist: serialized form
    Persist-->>MCPSurface: saved
    MCPSurface-->>Agent: MCP response
```

The flow is uniform across operations. Variations are in which Domain modules are invoked (mutations vs renders vs counterfactuals) but the layer transitions follow this pattern.

---

## 6. Cross-cutting concerns

Some concepts span layers. The architecture documents their placement once here; specs do not redefine them.

### 6.1 Consent tokens
- **Interface**: shape validation only (token present, has source field)
- **Domain**: semantic validation (source allowed for this operation, rationale meets requirements)
- **Engine**: consent appears as opaque metadata args on facts; Engine ignorant of meaning

### 6.2 Operation log
- **Domain**: owns the log structure; appends on every successful mutation
- **Interface**: persists the log as part of state file
- **Engine**: not aware

### 6.3 Rounds and phases
- **Domain**: round counter, phase computation, body-advancement detection
- **Engine**: round appears as a value in fact arguments; not interpreted
- **Interface**: surfaces round in tool responses

### 6.4 Action labels
- **Domain**: assigned during restructuring or mutation; attached to facts as metadata
- **Engine**: carries labels transparently; does not reason about them
- **Interface**: receives labels in tool inputs; reports them in tool outputs

### 6.5 Provenance and citations
- **Engine**: produces derivation trees on `explain()`
- **Domain**: wraps trees with action-label metadata, restructuring lineage, ratification history
- **Interface**: formats provenance for the wire

### 6.6 Approval (ratification)
- **Engine**: approval is a regular fact (`approved/3`) with no special semantics
- **Domain**: enforces that approval is required for elements to enter the derived set (via body literals in element rules); cascades on revision; tracks approval history
- **Interface**: exposes approval as the `ratify` MCP tool

---

## 7. State persistence model

The proof's state is durable: persisted to a JSON file per atomic mutation.

```mermaid
flowchart LR
    StateFile[(state.json)]
    
    subgraph load [On every operation]
        Read[Read file]
        Deserialize[Deserialize]
        Rebuild[Rebuild Engine state]
    end
    
    subgraph save [After successful mutation]
        Snapshot[Snapshot Engine]
        Serialize[Serialize]
        WriteTmp[Write state.tmp]
        Rename[Atomic rename]
    end
    
    StateFile --> Read
    Read --> Deserialize
    Deserialize --> Rebuild
    Rebuild -.->|operation runs| Snapshot
    Snapshot --> Serialize
    Serialize --> WriteTmp
    WriteTmp --> Rename
    Rename --> StateFile
```

Properties:
- **Atomic writes**: temp file plus rename guarantees no partial state on crash
- **Schema versioning**: state files carry a schema version; loadState backfills missing fields for compatibility
- **No in-memory persistence between operations**: each MCP call loads fresh, mutates, saves, returns. No long-lived process state.

This means the engine is rebuilt on every operation. For proofs at the expected scale (low thousands of facts), this is fast; if proofs grow larger, the architecture admits a cached-engine optimization without changing layer contracts.

---

## 8. Adversary integration (future)

The Adversary role attaches at the Interface layer as just another client. It reads the Datalog projection of state via a query tool and submits attack patterns through the same MCP surface as the primary Agent.

```mermaid
flowchart LR
    Agent([Primary Agent])
    Adversary([Adversary Agent])
    Designer([Designer])
    
    subgraph proofmcp [Proof MCP]
        Surface[MCP Tool Surface]
    end
    
    StateFile[(state.json)]
    
    Agent -->|mutate| Surface
    Adversary -->|query, probe| Surface
    Designer -->|ratify, withdraw| Surface
    Surface <--> StateFile
```

The Adversary is structurally indistinguishable from any other client. Its role is enforced by what it does, not by special privileges. Tools available to the Adversary include:
- `query_proof` — ad-hoc Datalog queries against the projection
- `runCounterfactual` — collapse_test verification
- `withdraw` — with appropriate disposition (typically `found-incorrect`)
- `manage_friction` — to register tensions the Agent missed

The architecture does not yet wire the Adversary's specific behaviors; it is anticipated to live as a separate skill or process invoking the proof MCP.

---

## 9. What this architecture does NOT prescribe

To keep the architecture document focused, several things are deferred to specifications or operational decisions:

- **Implementation language.** The Domain and Interface are written in JavaScript currently; the Engine could be JS or WASM-bridged native. Layer choices do not depend on language.
- **Specific Datalog dialect.** Decided in the Engine Spec.
- **Specific MCP tool list.** Decided in the Interface Spec.
- **Specific closure conditions.** Decided in the Domain Spec.
- **Specific schemas per element type.** Decided in the Domain Spec.

This document specifies the *shape*; the specs supply the *content*.

---

## 10. Architectural payoffs

The hexagonal layering pays off in:

- **Engine reusable**: the Datalog evaluator can ship as a separate package; other tools that want forward-chaining over typed facts can use it.
- **Domain testable without Interface**: the Domain has a programmatic surface; tests can exercise it without going through MCP.
- **Interface replaceable**: switching from MCP to HTTP is a Interface-layer change; Domain and Engine untouched.
- **Counterfactuals come for free**: the snapshot/restore primitive at Engine level lets the Domain implement collapse_test verification without bespoke machinery.
- **Independent verification path**: the Datalog projection of state can be loaded into a different engine for independent confirmation; the architecture admits this as a first-class adapter.
- **Adversary integrates cleanly**: the Adversary uses the same Interface as the primary Agent; no special privileges or pathways needed.

---

## 11. What this architecture costs

- **Indirection**: a mutation flows through three layers. For a system whose primitives are simple, this is more ceremony than a single-module implementation.
- **Discipline**: contributors must respect the inward dependency rule. Slipping (e.g., Interface calling Engine directly) corrupts the architecture's value.
- **Engine choice locked-in**: while the Engine is replaceable in principle, the Domain's queries and rules are written for a specific dialect. Switching engines requires rewriting Domain queries.
- **Persistence latency**: rebuilding the Engine on every operation has a fixed cost. At expected scale this is acceptable; at larger scale, requires optimization.

These costs are accepted in exchange for the payoffs above. They are appropriate for a system whose value is measured in correctness and clarity rather than raw throughput.

---

## 12. Sizing

Approximate code volumes per layer in the planned implementation:
- **Engine**: 500-800 lines of pure JavaScript; no third-party dependencies
- **Domain**: 1500-2500 lines, including all policies, schemas, lifecycle, render, counterfactual
- **Interface**: 600-900 lines, including MCP tool definitions, persistence, wire shaping
- **Total**: 2600-4200 lines

This is a meaningful reduction from the current ~4300-line monolith while gaining the architectural properties above. The reduction comes from policy externalizing into engine rules and procedural checkers consolidating into queries.

The test corpus is expected to remain similar in volume (~7000 lines), reorganized into per-layer suites.
