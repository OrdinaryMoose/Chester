---
status: Draft
last_reviewed: 2026-05-10
related_docs: [03-architecture, 05-domain-spec]
related_adrs: [0002, 0007]
---

# Engine Specification

This document specifies the Datalog evaluator that constitutes the bottom layer of the architecture. The Engine is generic, pure, and knows nothing about proofs.

---

## 1. Purpose and scope

The Engine provides forward-chaining Datalog evaluation: a fact store, a rule store, semi-naive evaluation to fixed point, query against the derived database, and snapshot/restore for counterfactuals. Its surface is small, its semantics are well-defined, and its termination is guaranteed.

Out of scope:
- Knowledge of proof concepts (Concerns, Necessary Conditions, dispositions)
- Persistence (Engine state is in-memory; serialization is a separate concern)
- Authority (consent, ratification, designer roles)
- Network or filesystem I/O

---

## 2. The Datalog dialect

### 2.1 Inclusions
The Engine implements **stratified Datalog with negation**: a subset chosen for decidable evaluation and matching the Domain's needs.

Included:
- **Horn clauses**: rules of form `head :- body₁, body₂, …, bodyₙ` where head is a positive atom and each body atom is positive or negated
- **Recursion**: rules may transitively refer to themselves (allowing transitive closure, ancestor relations, grounding chains)
- **Stratified negation**: `¬p(X)` admissible in body when `p` is fully evaluated in a lower stratum
- **Constants**: string, number, boolean, null
- **Variables**: identifiers (uppercase by convention) that bind to constants during evaluation
- **Multiple clauses per head**: alternative supporting paths (OR semantics)

### 2.2 Exclusions
- **Function symbols and complex terms**: arguments are constants only, not nested structures. (This is what makes Datalog terminating; full Prolog allows function symbols and is Turing-complete.)
- **Cut and other procedural operators**: no `!`, no ordering tricks
- **Arithmetic in heads**: arithmetic appears only in body comparisons and built-in predicates
- **Higher-order predicates**: no rule that takes a predicate as argument

### 2.3 Why this subset
Termination guarantees matter for a closure check. An agent (or designer) issuing a query must always get an answer in bounded time. Stratified Datalog has decidable evaluation: every well-formed program terminates with a unique minimal model. This is what makes the Engine load-bearing for closure verification.

---

## 3. Semantics

### 3.1 Fixed-point evaluation
The minimal model of a Datalog program is the smallest set of facts derivable from base facts by exhaustive rule application. The Engine computes this by **semi-naive evaluation**:
1. Initialize derived set ∅
2. In each iteration: apply every rule whose body is now satisfied by base ∪ derived; add new heads to a delta set
3. Merge delta into derived; new delta becomes input for next iteration
4. Terminate when delta is empty (no new facts derivable)
5. Final state: base ∪ derived = the fixed point

Semi-naive (vs naive) avoids re-deriving known facts by tracking which deltas changed in the prior iteration; rules only fire on new facts.

### 3.2 Stratification
Rules are organized into strata by negation dependency:
- Stratum 0: rules with no negated body literals
- Stratum N: rules whose negated body atoms refer to predicates fully evaluated in strata 0..N-1
- Each stratum is fully evaluated to fixed point before higher strata begin

If a program cannot be stratified (cyclic negation), the Engine refuses it at rule-definition time.

### 3.3 Query semantics
A query is a pattern with variables. Evaluating a query against the fixed point returns the set of variable bindings that make the pattern match facts. Patterns can be:
- Ground patterns (no variables): returns boolean (does this fact hold?)
- Variable patterns: returns binding sets
- Mixed: returns binding sets for the variables, filtered by the constants

### 3.4 Determinism
Given the same base facts and rules, the Engine produces the same fixed point and the same query results. No randomization, no implementation-defined ordering effects on results.

---

## 4. Public API

The Engine's surface is intentionally small. All public operations live here.

### 4.1 Fact operations
- `assertFact(predicate, args)` — write a base fact. Idempotent (asserting an existing fact has no effect).
- `retractFact(predicate, args)` — remove a base fact. Idempotent (retracting an absent fact has no effect).
- `factExists(predicate, args)` — boolean test for fact presence in the base set.

### 4.2 Rule operations
- `defineRule(ruleId, headAtom, bodyAtoms, metadata)` — write a Horn clause. RuleId must be unique. Metadata is opaque to the Engine; carried through for the Domain's use.
- `undefineRule(ruleId)` — remove a rule by id.
- `getRule(ruleId)` — return the rule shape (head, body, metadata) for inspection.

### 4.3 Evaluation
- `derive()` — compute fixed point from current base + rules. Idempotent. Required before queries reflect recent assertions.
- `isDerived()` — boolean, true if the current state has been derived to fixed point since the last mutation.

### 4.4 Query
- `query(pattern)` — return list of variable bindings satisfying the pattern. Triggers `derive()` if not already derived.
- `count(pattern)` — return integer count of bindings (cheaper than enumerating).
- `exists(pattern)` — boolean, returns true iff at least one binding exists.

### 4.5 Explanation
- `explain(fact)` — return a derivation tree showing why this fact appears in the fixed point. Each node names the rule that fired and the sub-facts that satisfied its body. Returns null if the fact is not in the derived set.

### 4.6 Snapshot
- `snapshot()` — return an opaque token representing current full Engine state (base + rules + derived + metadata).
- `restore(token)` — replace Engine state with the snapshot. Used by Domain's counterfactual module: `let s = snapshot(); retractFact(...); derive(); query(...); restore(s);`
- Snapshots are reference-cheap (no full copy until mutation; copy-on-write internally if useful).

### 4.7 Lifecycle
- `clear()` — empty the Engine entirely (no facts, no rules).
- `serialize()` — return a JSON-serializable representation of base facts and rules (not the derived set; that recomputes on load).
- `loadFrom(serialized)` — populate Engine from a serialized form.

---

## 5. Internal data structures

The specification names the structures conceptually; the implementation may optimize while preserving observable semantics.

### 5.1 Fact store
- Indexed by predicate symbol (primary index)
- Per-predicate secondary indexes on each argument position for fast join lookups
- Set semantics: no duplicates within a predicate

### 5.2 Rule store
- Indexed by rule id (primary)
- Secondary index by head predicate (for "which rules might derive p?")
- Stratification metadata per rule (which stratum it belongs to)

### 5.3 Derived set
- Same shape as fact store but for facts produced by rule firing
- Cleared and rebuilt by each `derive()` call
- Per-fact provenance tag (which rule + which body bindings produced this), used by `explain`

### 5.4 Predicate dependency graph
- Directed graph: edge from p to q if a rule with head p has q in its body
- Negated edges marked specially
- Used to compute stratification and to detect cycles through negation (which cause refusal)

---

## 6. Concrete API examples (conceptual)

### 6.1 Asserting facts
```
assertFact("evidence", ["evid_3", "no version carries scope manifest", "codebase"])
assertFact("rule_decl", ["rule_1", "every deploy must produce recoverable artifact"])
```

### 6.2 Defining a rule
```
defineRule(
  ruleId: "ncon_3_grounding",
  headAtom: ["ncon", ["ncon_3", S]],
  bodyAtoms: [
    ["evidence", ["evid_3", "_", "_"]],
    ["rule_decl", ["rule_1", "_"]],
    ["approved", ["ncon_3", "_", "_"]]
  ],
  metadata: { domain_concept: "necessary_condition", inference_pattern: "grounds_imply_conclusion" }
)
```

The Domain layer constructs these calls; the Engine doesn't know what `ncon`, `approved`, or `evidence` mean.

### 6.3 Querying
```
query(["ncon", [N, S]])
// returns [ {N: "ncon_3", S: "..."}, {N: "ncon_5", S: "..."}, ... ]

count(["addresses", ["_", "cern_2"]])
// returns 2

exists(["ungrounded_ncon", [N]])
// returns false
```

### 6.4 Counterfactual
```
const snap = snapshot()
retractFact("approved", ["ncon_3", "_", "_"])
derive()
const stillCovered = query(["covered", ["cern_2"]])
restore(snap)
// stillCovered tells the Domain whether ncon_3's approval was load-bearing
```

---

## 7. Error model

The Engine raises exceptions for:
- **Malformed rules**: head not a positive atom, body atoms with wrong shape
- **Stratification failure**: cyclic negation
- **Type errors**: assertFact called with non-constant value where constants required
- **Storage failure**: any condition under which the Engine cannot produce a deterministic answer

The Engine does not classify errors by domain concern (no `INVALID_CONSENT`, `PROOF_FINISHED`, etc.). Domain-specific error codes are the Domain layer's responsibility.

---

## 8. Performance characteristics

For the proof system's expected scale (low thousands of facts, hundreds of rules), the Engine should support:
- Sub-millisecond fact assertion and retraction
- Single-digit-millisecond query latency for typical patterns
- Sub-second full derivation from scratch
- O(facts + rule-fires) memory footprint

Optimization targets in priority order:
1. Index quality (join performance dominates query cost)
2. Semi-naive correctness (avoid redundant rule fires)
3. Snapshot copy-on-write (minimize counterfactual cost)
4. Incremental re-derivation (when feasible, recompute only deltas)

These targets are aspirations; the initial implementation can ship with naive evaluation if it meets the latency budgets and optimize later.

---

## 9. Test obligations

The Engine ships with its own test suite, exercised independently of the Domain.

### 9.1 Canonical Datalog test cases
- **Transitive closure**: ancestor relation over a parent graph
- **Reachability**: graph reachability with cycles
- **Stratified negation**: same-generation cousins (negation over a recursive predicate)
- **Multiple clauses per head**: alternative grounding paths
- **Empty programs**: empty fact and rule sets

### 9.2 Property tests
- **Monotonicity**: adding facts never removes facts from the fixed point (in absence of retractions)
- **Idempotency**: `derive(); derive();` produces the same state as `derive();`
- **Termination**: every well-stratified program terminates in bounded time
- **Snapshot fidelity**: `snap = snapshot(); mutate(); restore(snap);` returns Engine to bit-equal pre-mutation state

### 9.3 Stress tests
- Large fact stores (10k+ facts) with realistic query patterns
- Deep recursion (transitive closure on long chains)
- Many rules with shared bodies (join performance)

### 9.4 Failure-mode tests
- Cyclic negation correctly refused at rule-define time
- Malformed rules rejected with clear error messages
- Large-but-bounded programs do not exceed memory budget

---

## 10. Implementation notes

These are guidance for implementers, not contracts.

### 10.1 Language choice
JavaScript / TypeScript is the natural choice given the existing proof MCP is Node-based. The Engine has no third-party dependencies beyond the language standard library; this is intentional (minimizes audit surface, simplifies licensing).

### 10.2 Implementation size
500-800 lines for a clean implementation with stratified negation, indexes, and snapshot support. The reference algorithms are well-documented (Wikipedia's Datalog page, Abiteboul/Hull/Vianu textbook chapter on Datalog).

### 10.3 What NOT to add
- **Aggregations** (sum, count, min, max in head atoms): valuable but add complexity; defer until demonstrated need
- **User-defined functions in rule bodies**: tempting but breaks Datalog's purity; defer indefinitely
- **External fact sources**: keep all facts in-memory and Domain-supplied; external sources couple the Engine to I/O
- **Multi-threaded evaluation**: single-threaded semi-naive is adequate at expected scale; concurrency adds complexity without compensating benefit

### 10.4 What to consider adding later
- **Built-in comparison predicates** (`<`, `>`, `=`, `≠`) for body conditions: small addition, big ergonomic win
- **Magic-set rewriting** for query optimization: unlocks a class of efficient evaluations; only add if measured to matter
- **Incremental maintenance** (delta-based update rather than full rederivation): valuable for live-updating displays; defer until needed

---

## 11. Boundary contract summary

What the Domain can rely on from the Engine:
- Pure functions: same inputs produce same outputs
- Deterministic evaluation
- No I/O, no global state beyond what the Engine itself manages
- Termination on all well-formed programs
- Snapshot/restore preserves bit-equal state
- Errors raised as exceptions with structured data

What the Engine relies on from the Domain:
- Predicate names and argument types are consistent within a single Engine instance
- Stratification holds (no cycles through negation)
- Snapshots are not mutated externally
- Rule ids are unique within a single Engine instance

The Engine does not validate that predicate uses are consistent with element categories — that's Domain responsibility. The Engine treats `evidence(...)` and `ncon(...)` as just predicates with arguments.
